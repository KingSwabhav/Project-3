//This project creates a Student Management System
import java.util.*;
import java.io.IOException;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.FileWriter;



interface  SMS
{
    public void printArray();
    public void checkID(int dID);
    public void findID(int fID);
    public String returnF();
    public String returnL();
    public int returnID();
    public String returnLev();

}
interface CMS
{
public void display();
}
public class SwabhavMukhia_Section002_Project3 
{

    public static void main(String[] args) throws IOException
    {      
            Boolean check = true; /*ENSURES WHILE LOOP KEEPS RUNNING WHILE TRUE*/
            int i = 0; /* STORES NUMBER AND MAKE SURE ID WORKS*/
            int iD;
            Scanner scanner = new Scanner(System.in); /* ENSURES THAT WHEN YOU INPUT A VALUE IT GETS RECOGNIZED*/
           
            System.out.println("\tWelcome to the Student and Course Management System!");
            System.out.print("\nThis system will allow you to manage students."
                             + " Let's start with the number of student this system will have: ");
            int length =  scanner.nextInt(); // ENSURES THE NUMBER YOU PUT IS THE LENGTH//
            Student[] arr = new Student[length]; // ARRAY FOR STUDENT//
            Student_Employee[] stu = new Student_Employee[length]; // ENSURES THE NUMBER YOU PUT IS THE LENGTH//
            Boolean[] arr3 = new Boolean[length];
            while(check  == true)
            {
           
            //Asks the users to pick an option
                System.out.println("\n***Welcome to Student and Course Management System***" +
                "\nPress '1' for Student Management System (SMS)" +
                "\nPress '2' for Course Management System (CMS)" +
                "\nPress '0' to exit\n");

            
                int option = scanner.nextInt(); 
               
                
                switch(option) //YOU CAN CHOOSE ONE OF THE 3 OPTIONS//
                { 
                
                    case  1: //ADDS STUDENT TO DATABASE
                    {  
                    Boolean checker = true;
                    while(checker)
                    {
                    System.out.println("***Welcome to SMS***\n" + // DISPLAYS CHOICES//
                    "\nPress '1' to add student" +
                    "\nPress '2' to deactivate a student" +
                    "\nPress '3' to display all students" +
                    "\nPress '4' to search for a student by ID" +
                    "\nPress '5' to assign on-campus job" +
                    "\nPress '6' to display all students with on-campus jobs" +
                    "]nPress '0' to exit SMS.\n");
                    int choice = scanner.nextInt();
                   
                    switch(choice)
                    {
                    case 1:
                    {
                                    if (i >= length) // ENSURES YOU DO NOT HAVE MORE THAN THE AMOUNT OF STUDENTS//
                                    {
                                            System.out.println("Error, max number of students has been reached");
                                            break;
                                    }                            
                                    System.out.print("Enter first name: "); //INPUT FIRST NAME//
                                    scanner.nextLine();
                                    String fName = scanner.nextLine();
                                                                      
                                    System.out.print("Enter last name: "); // INPUT LAST NAME//
                                    String lName = scanner.nextLine();

                                    System.out.print("Enter level of the student: ");  //INPUT LEVEL OF STUDENT//                                 
                                    String level = scanner.nextLine();

                                    iD = new Random().nextInt(99 + 1); // CHOOSE ID NUMBER 0 - 99
                                    arr[i] = new Student(fName, lName, level, check, iD, "null", "null");
                                    stu[i] = new Student_Employee(fName, lName, level, check, iD, "null", "null");
                 
                                    
                                    System.out.println("\n" + fName + " " + lName + " has been addded as a " + level + " with ID " +iD); //DISPLAYS STUDENTS FULL NAME, LEVEL, AND ID 
                                    arr3[i] = false;
                                    i++;
                    break;
                    }
                    case 2:
                    {
                    System.out.print("Enter the ID for the student that you want to deactivate: "); // ASKS TO DEACTIVATE GIVEN STUDENT ID //
                                    int dID = scanner.nextInt();
                                   
                                    for(int l = 0; l < i; l++) // CHECKS ARRAY//
                                    {
                                        arr[l].checkID(dID);
                                    }
                                    break;
                    }
                    case 3:
                    {
                                    if(i > 1) // ARRAY IS ORDERED ALPHABETICALLY FROM THE FIRST NAME IF THERE IS MORE THAN ONE STUDENT
                                    {
                                        for(int o = 0; o < i; o++) // ARRAY IS OREDERED ALPHABETICALLY BY FIRST NAME AND MOVES IT TO THE ARRAY
                                        {
                                            for(int u = o + 1; u < i; u++) // CHECKS ARRAY//
                                            {
                                                String first = arr[o].returnF();
                                                String second = arr[u].returnF();
                                                if(first.compareTo(second) > 0)
                                                {
                                                    Student temp = arr[o];
                                                    arr[o] = arr[u];
                                                    arr[u] = temp;
                                                }
                                            }
                                        }
                                    }
                                    for(int o = 0; o < i; o++)
                                    {
                                    arr[o].printArray();
                                    }
                                    break;
                    }
                    case 4:
                    {
                    System.out.print("Enter student ID: "); // INPUT STUDENT ID)
                                    int fID = scanner.nextInt();
                                    for(int y = 0; y < i; y++)// CHECKS ARRAY//
                                    {
                                        arr[y].findID(fID); 
                                    }
                                    break;
                   
                    }
                    case 5:
                    {
                    System.out.print("Enter student ID: "); // INPUT STUDENT ID
                    int studentID = scanner.nextInt(); // ENSURE YOU CAN INPUT//
                    System.out.print("\nEnter job: "); // INPUT JOB//
                    scanner.nextLine(); // ENSURE THAT YOU CAN INPUT//
                    String job = scanner.nextLine();
                    System.out.print("\nEnter job type: "); // INPUT JOB TYPE//
                    String jobW = scanner.nextLine();
                    for(int o = 0; o < i; o++)
                    {
                    if(studentID == (arr[o].returnID()))
                    {
                    System.out.println(arr[o].returnF() + " " + arr[o].returnL() + " has been assigned " + jobW + " " + job + "job");
                    stu[o] = new Student_Employee(arr[o].returnF(), arr[o].returnL(), arr[o].returnLev(), check, arr[o].returnID(), job, jobW);
                    arr3[o] = true;
                    }
                    }
                   
                    break;
                    }
                    case 6:
                    {
                    for(int r = 0; r < i ; r++)
                                    {
                    if(arr3[r] == true)
                    {
                    stu[r].displayJob();
                    }
                                    }
                    break;
                    }
                    case 0:
                    {
                    checker = false;
                                    break;
                    }
                    default:
                    {
                    System.out.println("Error, please try again"); // DISPLAYS MESSAGE IF SOMETHING IS WRONG WITH INPUT//
                    }
                   
                    }
                    }
                        break;
                       
                    }
                   
                    case 2:
                    {
                        Boolean checking = true;
                    while(checking)
                    {
                    System.out.println("***Welcome to CMS***\n" +
                    "Press '1' to add a new course" +
                    "Press '2' to assign a student to a new course" +
                    "Press '3' to display students with assigned courses" +
                    "Press '0' to exit CMS");
                    int cs = scanner.nextInt();
                    switch(cs)
                    {
                        case 1:
                        {
                        System.out.print("Enter course ID: "); // INPUT COURSE ID//
                        int courseID = scanner.nextInt();
                        System.out.print("Enter course name: "); // INPUT COURSE NAME //
                        scanner.nextLine();
                        String courseN = scanner.nextLine();
                        File catalog = new File("Courses.txt");
                        try
                        {          
                        if(!catalog.exists()) // ENSURES WE ARE USING THAT CLASS//
                        {
                        catalog.createNewFile(); // ENSURES WE ARE USING THAT CLASS//
                        }
                        else
                        {
                        System.out.println("File already exists"); // DISPLAYS MESSAGE IF FILE ALREADY EXISTS//
                       
                        }
                        FileWriter writer = new FileWriter(catalog, true);
                        writer.write("Course ID: " + courseID + "\n" + "Course Name: " + courseN + "\n");
                        System.out.println("Confirmation: New Course " + courseID + " has been added");
                        writer.close();
                        }catch (IOException e)
                        {
                        e.printStackTrace();
                        }
                        break;
                       
                        }
                        case 2:
                        {
                        System.out.println("Enter student ID: "); // INPUT STUDENT ID//
                        int stuID = scanner.nextInt();
                        System.out.println("Enter course ID: "); // INPUT COURSE ID//
                        int cID = scanner.nextInt();
                        File M = new File("CourseAssignment.txt");
                        try {
                       
                        if(!M.exists()) // ENSURES CORRECT FILE//
                        {
                        M.createNewFile();// ENSURES CORRECT FILE//
                        }
                        else
                        {
                        System.out.println("File already exists"); // DISPLAYS IF FILE EXISTS//
                       
                        }
                       
                        FileWriter writer = new FileWriter(M);
                    for(int z = 0; z < i; z++)
                    {
                    if(stuID == arr[z].returnID())
                    {
                    System.out.println("Confirmation: " + arr[z].returnF() + " " + arr[z].returnL() + "has been assigned course " + cID);
                    writer.write(arr[z].returnF() + " " + arr[z].returnL() + "\n");
                    writer.write("ID: " + stuID + "\n");
                    writer.write("Courses: " + cID + "\n\n" );
                    }
                    }
                    writer.close();
                        }catch (Exception e) {
                        e.printStackTrace();
                        }
                        break;
                        }
                        case 3:
                        {
                        Course c = new Course(1, "i");
                        c.display();
                       
                        }
                        case 0:
                        {
                        checking = false;
                                    break;
                        }
                        default:
                        {
                        System.out.println("Error, please try again");
                        }
                    }
                    }
                        break;
                    }
                    case 0:
                    {
                        check = false;
                        break;
                    }
                    default:
                    {
                        System.out.println("Error, please try again");
                    }
               }
               
            }
                   
            System.out.println("Good Bye!!!\n"); //Displays SYSTEM HAS EXITED//
            return;
    }

}