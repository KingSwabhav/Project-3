public class Student implements SMS

{

    String fName; //RECOGNIZED VALUE//

    String lName; //RECOGNIZED VALUE//

    String level; //RECOGNIZED VALUE//

    String active; //RECOGNIZED VALUE//

    Boolean check; //RECOGNIZED VALUE//

    int iD; //RECOGNIZED VALUE//

    String job; //RECOGNIZED VALUE//

	String jobW; //RECOGNIZED VALUE//

    

	//MAKE SURE STUDENT HAS VALUES//

    public Student(String fName, String lName, String level, Boolean check, int iD, String job, String jobW)

    {

        this.fName = fName;

        this.lName = lName;

        this.level = level;

        this.check = check;

        this.iD = iD;

        this.job = job;

        this.jobW = jobW;

    }

    


    public void printArray() // ENSURES ARRAY RUNS CORRECTLY//
 
    {


        if(check == true) // CHECKS IF VALUE IS TRUE

        {

            active = "Active";

        }

        

        else // IF NOT THEN INACTIVE//

        {

            active = "Inactive";

        }

        

        //Displays STUDENTS FULL NAME, ID, LEVEL, AND STATUS//

        System.out.println("\n" +  fName + " " + lName + "\n" +  "ID: " + iD + "\nLevel: " + level + "\nStatus: " + active);

    }

    


    public void checkID(int dID) // PRINT ARRAY

    {


        if(dID == iD) // CHECKS IF VALUE IS EQUAL TO ID

        {

            check = false;

            System.out.println("\n" + fName + " " + lName + " has been deactivated");

        }

    }

    


    public void findID(int fID) // PRINTS ARRAY//

    {

        if(fID == iD)

        {

            System.out.println("\n" + fName + " " + lName + "\n" +  "ID: " + iD + "\nLevel: " + level + "\nStatus: " + active);

        }



    }

    


    public String returnF() // RETURNS FNAME//

    {

        return fName;

    }

    public String returnL()

    {

        return lName;

    }

    public int returnID()

    {

        return iD;

    }

    public String returnLev()

    {

        return level;

    }

    

}