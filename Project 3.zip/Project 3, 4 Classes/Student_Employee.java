
public class Student_Employee extends Student

{

	String job;

	String jobW;

	String fName;

	String lName;

	String level;

	String active;

	Boolean check;

	int iD;

	

	public Student_Employee(String fName, String lName, String level, Boolean check, int iD, String job, String jobW)

	{

		super(fName, lName, level, check, iD, job, jobW);

		this.fName = fName;

        this.lName = lName;

        this.level = level;

        this.check = check;

        this.iD = iD;

        this.job = job;

        this.jobW = jobW;

	}



	public void displayJob()

	{

		

		System.out.println("\n" +  fName + " " + lName + "\n" +  "ID: " + iD + "\n" + jobW + " " + job);

	}

	public String returnJ()

	{

		return job;

	}

	

	

}