import java.io.File;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

public class Course implements CMS
{
int courseID;
String courseN;
File catalog = new File("CourseAssignment.txt");

public Course(int courseID, String courseN)
{
this.courseID = courseID;
this.courseN = courseN;
}
public void display()
{
String line = null;
try {
FileReader fileReader = new FileReader(catalog); // STREAM THAT CONNECTS FILE //
BufferedReader bufferedReader = new BufferedReader(fileReader); // Connect FileReader to BufferedReader //

while((line = bufferedReader.readLine()) != null) {
System.out.println(line); // DISPLAYS FILE CONENTS ONE LINE AT A TIME
}

bufferedReader.close(); // CLOSE THE STREAM
} catch (IOException e) {
System.out.println("No CourseAssignment.txt file found.");
e.printStackTrace();
}

}
}